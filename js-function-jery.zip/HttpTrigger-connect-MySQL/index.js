var util = require('util');

module.exports = function (context, req) {
    context.log('Start>>>>>>>>>>>>>>>>>>>>>>');

    const mysql = require('mysql');
    var config = {
        host: 'jery-mysql.mysql.database.azure.com',
        user: 'jery@jery-mysql',
        password: 'Qazxsw521',
        database: 'test-func',
        port: 3306,
        ssl: true
    };

    const conn = new mysql.createConnection(config);
 
    conn.connect(
        function (err) {
            if (err) {
                context.log("!!! Cannot connect !!! Error:" + err);
                context.done();
            } else {
                context.log("Connection established.");
                checkUserExists(req.body.Email, req.body.SuperEmail);
            }
    });

    context.log("Email:" + req.body.Email);
    context.log("superEmail:" + req.body.SuperEmail);

    function checkUserExists(email, superemail) {
        context.log('1');
        console.log("checkUserExists start>>>>>>>>>>>>>> " + email)
        conn.query('SELECT * FROM `test-func-table` WHERE `Email` = ?',email,
            function (err, results, fields) {
                if (err){
                    context.log(err);
                    context.done();
                } 
                else if (results.length != 0){
                    context.log('Selected ' + results.length + ' row(s).');
                    for (i = 0; i < results.length; i++) {
                        context.log('Row: ' + JSON.stringify(results[i]));
                    }
                    //context.res={body:"Record Found"};
                    context.log('Info: User already Exists.');
 
                    // Send Email Notification to User, Supervisor and CloudBurner Support
                    let message = {
                        "personalizations": [ { "to": [ { "email": req.body.userEmail } ],
                                        "cc": [{"email": req.body.superEmail},{"email": "cloudburner@publicissapient.com"}] } ],
                        subject: "Azure Burner Subscription Already Exists!",
                        content: [{
                            type: 'text/html',
                            value: "<h1>An Azure Subscription with the email id </h1>" + email + " already exists."
                        }]
                    };
                    context.res = {
                        status: 200,
                        body: "User already Exists"
                    }
                    context.done(null, message);
                }
                else {
                    context.log('Info: User Request is New.');
                    context.log('2');

                    conn.query('INSERT INTO `test-func-table` (Email, SuperEmail) VALUES (?, ?);', [ email, superemail ], 
                        function (err, results, fields) {
                                if (err) {
                                    context.log(err);
                                    context.done();
                                };
                            context.log('Inserted ' + results.affectedRows + ' row(s).');
                        })
                    
                    context.log("Insert finished<<<<<<<<<<<<<");
                    context.res = {
                        status: 200,
                        body: "successfully inserted!!!!!!!!!"
                    };
                    context.done();
                }
            })
    }; 
    //context.done();
};