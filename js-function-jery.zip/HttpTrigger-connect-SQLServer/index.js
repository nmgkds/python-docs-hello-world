let Connection = require('tedious').Connection;
let Request = require('tedious').Request;

module.exports = function (context, req) {
    context.log('Start>>>>>>>>>>>>>>>>>>');

    let config = {
        authentication: {
            options: {
                userName: 'jery',
                password: 'Qazxsw521'
            },
            type: 'default'
        },
        server: 'jery-sqlserver.database.windows.net',
        options: {
            database: 'test-func-sql',
            encrypt: true
        }
    }

    let connection  = new Connection(config);

    connection.on('connect', (err) => {
        if(err) {
            context.log(err);
            context.res = {
                status: 500,
                body: "Failed to connect to SQL"
            };
            context.done();
        } else {
            context.log('Connected!!!!!!');
            // queryDatabase();
            modifyDatabase();
            queryDatabase();
            //context.done();
        }
    })


    function queryDatabase()
    {
        context.log('Reading...');

        // Read all rows from table
        var request = new Request(
            "SELECT * FROM [dbo].[emails]",
            function(err, rowCount, rows)
            {
                context.log(rowCount + ' row(s) returned');
                context.done();
            }
        );

        request.on('row', function(columns) {
            columns.forEach(function(column) {
                context.log("%s\t%s", column.metadata.colName, column.value);
            });
        });
        connection.execSql(request);
    }

    function modifyDatabase()
    {
        context.log('Modify....');

        // Read all rows from table
        var request = new Request(
            "INSERT INTO [dbo].[emails] (first_email, second_email ) VALUES ('e@e.com', 'f@f.com');",
            function(err, rowCount, rows)
            {
                context.log(rowCount + ' row(s) returned');
                context.done();
            }
        );

        
        connection.execSql(request);
    }
};