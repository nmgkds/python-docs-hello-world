const mongodb = require("mongodb");
const mongourl = "mongodb://jerytest:IZ8nYAVROPoQL8kSalbtMwsAhBK8oKft7IdNMm6NFXHrPwinNVmxrGsmURfSD8N5yxFemsMRtIxX5DWG6epJ1A%3D%3D@jerytest.documents.azure.com:10255/?ssl=true&replicaSet=globaldb";
const dbName = "React";
const collectionName = "heros";

module.exports = async function (context, req) {
    context.log('Running');
    // mongodb.MongoClient.connect(mongourl, function (error, client) {
    //     if (error) {
    //         context.log('Failed to connect');
    //         context.res = { status: 500, body: res.stack }
    //         return context.done();
    //     }
    //     context.log('Connected');

    //     client.db(dbName).collection(collectionName).find().toArray(function (error, docs) {
    //         if (error) {
    //             context.log('Error running query');
    //             context.res = { status: 500, body: res.stack }
    //             context.done();
    //         }

    //         context.log('>>>>>>>>>>>>>>>Success!');
    //         context.res = {
    //             headers: { 'Content-Type': 'application/json' },
    //             body: JSON.stringify({ res: docs })
    //         };
    //         context.done();
    //     });
    // });

    
    
    try{
        let client = await mongodb.MongoClient.connect(mongourl); 
        context.log('Connected');

        let data = await client.db(dbName).collection(collectionName).find().toArray();

        context.log(`<<<<<<<<<<<<<<<found! ${data}`);
        context.res = {
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ res: "docs" })
        };

    } catch(err) {
        context.log('<<<<<<<<<<<<<<<failed!');
        context.res = {
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ res: "123" })
        };
    }

};