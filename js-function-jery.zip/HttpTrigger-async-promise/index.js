const request = require('request');
const util = require('util');
const call_api_async= util.promisify(request);

module.exports = async function (context, req) {
    var IoTHubMessages2 = ["msg1", "msg2"];
    context.log('IoTHubMessages2:'+IoTHubMessages2+"|count:"+IoTHubMessages2.length);    
    context.log(`JavaScript eventhub trigger function called for message array ${JSON.stringify(IoTHubMessages2)}`);

    var message='null';
    var result='';

    let num = IoTHubMessages2.length;

    await callFunc(num, IoTHubMessages2, context);
};

async function callFunc(num, IoTHubMessages2, context) {
    if(num <= 0) {
        context.log(`>>>>>All Message Cleared`);
        context.done();
    } else {
        context.log(`>>>>>>>>>>>>>>>>before post_api`);
        message=IoTHubMessages2[num-1];
        try {
            context.log(`>>>>await post_api`);
            result = await call_api_async("https://ehtest.azurewebsites.net/api/HttpTrigger2?name="+message);
        } catch (err) {
            context.log.error('ERROR', err);
            context.res = { status: 500, body: err }
            context.done();
        }
        context.log(`>>>>>>>>>>>>>>>>after post_api`);
        context.res = { status: 200, body: result.body };
        
        // await call_api(context, message);
        await promise_api(context, message);

        num--;
        context.log('num', num);
        return callFunc(num, IoTHubMessages2, context);
    }
}

async function call_api(context,message){
    context.log(`************Processed message ${message} at ${new Date()}**************`);

    // working fine with try-catch
    try {
        let res = await call_api_async('https://ehtest.azurewebsites.net/api/HttpTrigger2');
        context.log(`************after call_api**************`);
        context.log('body:', res.body);
    } catch (err) {
        context.log.error('ERROR', err);
        context.res = { status: 500, body: err }
        context.done();
    }
    
}

async function promise_api(context, message){
    context.log(`************Processed message ${message} at ${new Date()}**************`);

    return new Promise((resolve, reject)=> {
        request({
            method: 'POST',
            url: 'https://ehtest.azurewebsites.net/api/HttpTrigger2'
        },(error, response, body) => {
            if(error){
                console.error('error:', error); 
                console.log('statusCode:', response && response.statusCode); 
                console.log('body:', body);
                reject(error);
            } else {
                context.log(`************after call_api**************`);
                console.log('statusCode:', response && response.statusCode); 
                context.log('body:', body);
                resolve(response);
            }
        })
    })

}